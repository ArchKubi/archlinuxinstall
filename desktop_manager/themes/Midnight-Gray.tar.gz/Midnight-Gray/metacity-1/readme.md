# Credits
Metacity theme base on <b>Arc-Theme</b> </br>
Links : https://github.com/horst3180/arc-theme</br>
License : GPLv3 (https://choosealicense.com/licenses/gpl-3.0/)</br>

# Installation
Install themes : Extract Archive File On Directory<i> /.themes or /usr/share/themes (as root),</i> </br>

## Change themes
Linux Mint (Cinnamon): Menu > Settings > Themes > Themes > Window Borders</br>
